<html>
<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="favicon.ico">
		<title>Web and Vetted</title>
		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->
		<link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
	</head>
	<body id="page-top">
		<!-- Navigation -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<!--<div class="navbar-header page-scroll">-->
                    
							
					
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						
						<li>
							<a class="page-scroll" href="homepage.php">Home</a>
						</li>
						<li>
							<a class="page-scroll" href="About.php">About</a>
						</li>
						<li>
							<a class="page-scroll" href="Features.php">Features</a>
						</li>
						<li>
							<a class="page-scroll" href="Portfolio.php">Portfolio</a>
						</li>
						
						<li>
							<a class="page-scroll" href="Contact.php">Contact</a>
                        
						</li>
                        
                         <li>
							<a class="page-scroll" href="RE.php">Create Account</a>
						</li>
                        
                        
					</ul>
				</div>
				<!-- /.navbar-collapse -->
			
			<!-- /.container-fluid -->
		</nav>
        
      
  
          <!-- Text based logo -->
      
        
        <br/>
         
       <header id="aa-header">  
    <div class="container">
      <div class="row">
           <h1>Freelancer Directory</h1>
     <div class="row">
        <div class="col-md-12">
          <div class="aa-property-header-inner">
            <ol class="breadcrumb">
           
            <li class="active">DIRECTORY</li>
          </ol>
          </div>
        </div>
          </div>
      </div>
    </div>
  </header>

  <!-- End menu section -->


  <!-- Start Properties  -->
  <section id="aa-properties">
    <div class="container">
      <div class="row">
        <div class="col-md-8">
          <div class="aa-properties-content">
            <!-- start properties content head -->
            <div class="aa-properties-content-head">              
              <div class="aa-properties-content-head-left">
                <form action="" class="aa-sort-form">
                  <label for="">Sort by</label>
                  <select name="">
                    <option value="1" selected="Default">Default</option>
                    <option value="2">Name</option>
                    <option value="3">Price</option>
                  </select>
                </form>
                <form action="" class="aa-show-form">
                  <label for="">Show</label>
                  <select name="">
                    <option value="1" selected="12">6</option>
                    <option value="2">12</option>
                  </select>
                </form>
              </div>       
            </div>
            <!-- Start properties content body -->
            <div class="aa-properties-content-body">
              <ul class="aa-properties-nav">
                <li>
                  <article class="aa-properties-item">
                    <a class="aa-properties-item-img" href="#">
                      
                    </a>
                    <div class="aa-tag for-rent">
                      SEO
                    </div>
                    <div class="aa-properties-item-content">
                      <div class="aa-properties-info">
                        <span>Logo & Branding</span>
                        <span>Social Media</span>
                        <span>UX/UI Design</span>
                        <span>Web Hosting</span>
                      </div>
                      <div class="aa-properties-about">
                        <h3><a href="#">Okanagan Web Design</a></h3>
                        <p>A Kelowna BC website design and online marketing specialist.</p>                      
                      </div>
                      <div class="aa-properties-detial">
                        <span class="aa-price">
                          P2000
                        </span>
                        <a class="aa-secondary-btn" href="#">Okangan@mail.com</a>
                      </div>
                    </div>
                  </article>
                </li>
                <li>
                  <article class="aa-properties-item">
                    <a class="aa-properties-item-img" href="#">
                    
                    </a>
                    <div class="aa-tag sold-out">
                 SEO
                    </div>
                    <div class="aa-properties-item-content">
                      <div class="aa-properties-info">
                        <span>Logo & Branding</span>
                        <span>Social Media</span>
                        <span>WordPress</span>
                        <span>Web Hosting</span>
                      </div>
                      <div class="aa-properties-about">
                        <h3><a href="#">NET Masters</a></h3>
                        <p>is a dynamic, Johannesburg-based company. Net Age has over 15 years experience in online marketing and offers a variety of related services, from paid advertising to search engine optimisation.</p>                      
                      </div>
                      <div class="aa-properties-detial">
                        <span class="aa-price">
                          P1500
                        </span>
                        <a class="aa-secondary-btn" href="#">netmastrs@mail.com</a>
                      </div>
                    </div>
                  </article>
                </li>
                 <li>
                  <article class="aa-properties-item">
                    <a class="aa-properties-item-img" href="#">
                    </a>
                    <div class="aa-tag sold-out">
                    SEO
                    </div>
                    <div class="aa-properties-item-content">
                      <div class="aa-properties-info">
                         <span>Logo & Branding</span>
                        <span>Social Media</span>
                        <span>WordPress</span>
                        <span>Web Hosting</span>
                      </div>
                      <div class="aa-properties-about">
                        <h3><a href="#">Internet Marketing Gurus</a></h3>
                        <p> We specialize in web design and search engine optimization and are based in Cape Town.</p>                      
                      </div>
                      <div class="aa-properties-detial">
                        <span class="aa-price">
                          $35000
                        </span>
                        <a class="aa-secondary-btn" href="#">im@mail.com</a>
                      </div>
                    </div>
                  </article>
                </li>
                <li>
                  <article class="aa-properties-item">
                    <a class="aa-properties-item-img" href="#">
                    </a>
                    <div class="aa-tag for-sale">
                     Social Media
                    </div>
                    <div class="aa-properties-item-content">
                      <div class="aa-properties-info">
                         <span>Logo & Branding</span>
                        <span>Social Media</span>
                        <span>WordPress</span>
                        <span>Web Hosting</span>
                      </div>
                      <div class="aa-properties-about">
                        <h3><a href="#">My Diamond Logic</a></h3>
                        <p>We help great companies generate revenue through social media. Social Media Marketing with a ROI.</p>                      
                      </div>
                      <div class="aa-properties-detial">
                        <span class="aa-price">
                       P2000
                        </span>
                        <a class="aa-secondary-btn" href="#">diamond@gmail.com</a>
                      </div>
                    </div>
                  </article>
                </li>
                 <li>
                  <article class="aa-properties-item">
                    <a class="aa-properties-item-img" href="#">
                    </a>
                    <div class="aa-tag for-rent">
                   Social Media
                    </div>
                    <div class="aa-properties-item-content">
                      <div class="aa-properties-info">
                       <span>Logo & Branding</span>
                        <span>Social Media</span>
                        <span>WordPress</span>
                        <span>Web Hosting</span>
                      </div>
                      <div class="aa-properties-about">
                        <h3><a href="#">Social Bond</a></h3>
                        <p>delivers the ultimate set of tools for brands and influencers to manage their collaboration opportunities and track the results.</p>              
                      </div>
                      <div class="aa-properties-detial">
                        <span class="aa-price">
                          P1000
                        </span>
                        <a class="aa-secondary-btn" href="#">socialbond@yahoo.com</a>
                      </div>
                    </div>
                  </article>
                </li>
                 <li>
                  <article class="aa-properties-item">
                    <a class="aa-properties-item-img" href="#">
                    </a>
                    <div class="aa-tag for-sale">
                   Web Host
                    </div>
                    <div class="aa-properties-item-content">
                      <div class="aa-properties-info">
                       <span>Logo & Branding</span>
                        <span>Social Media</span>
                        <span>WordPress</span>
                        <span>Web Hosting</span>
                      </div>
                      <div class="aa-properties-about">
                        <h3><a href="#">JN Hosting</a></h3>
                        <p>provides Instant Web Hosting, Domain Registrations, SSL, VPS and Dedicated Servers at great rates. Best servers in the industry backed by top notch customer support.</p>                      
                      </div>
                      <div class="aa-properties-detial">
                        <span class="aa-price">
                          P1500
                        </span>
                        <a class="aa-secondary-btn" href="#">jnhosting@mail.com</a>
                      </div>
                    </div>
                  </article>
                </li>
              </ul>
            </div>
            <!-- Start properties content bottom -->
            <div class="aa-properties-content-bottom">
              <nav>
                <ul class="pagination">
                  <li>
                    <a href="#" aria-label="Previous">
                      <span aria-hidden="true">&laquo;</span>
                    </a>
                  </li>
                  <li><a href="#">1</a></li>
                  <li><a href="#">2</a></li>
                  <li class="active"><a href="#">3</a></li>
                  <li>
                    <a href="#" aria-label="Next">
                      <span aria-hidden="true">&raquo;</span>
                    </a>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
        <!-- Start properties sidebar -->
        <div class="col-md-4">
          <aside class="aa-properties-sidebar">
            <!-- Start Single properties sidebar -->
            <div class="aa-properties-single-sidebar">
              <h3>Narrow Down Your Search</h3>
              <form action="">
                <div class="aa-single-advance-search">
                  <input type="text" placeholder="Type Your Location">
                </div>
                  <br/>
                <div class="aa-single-advance-search">
                  <select id="" name="">
                     <option value="0" selected>Category</option>
                    <option value="1">Web Design</option>
                    <option value="2">Web Hosting</option>
                    <option value="3">SEO</option>
                    <option value="4">UX/UI Design</option>
                  </select>
                </div>
               
          <br/>
                
                <div class="aa-single-advance-search">
                  <input type="submit" value="Search" class="aa-search-btn" href="Freelancerlist.php">
                </div>
              </form>
            </div> 
            <!-- Start Single properties sidebar -->
            <div class="aa-properties-single-sidebar">
              <h3>Popular Searches</h3>
              <div class="media">
                <div class="media-left">
                  <a href="#">
                  </a>
                </div>
                <div class="media-body">
                  <h4 class="media-heading"><a href="#">Charity Box</a></h4>
                          <p>Web development For Schools</p>                
                          <span>15 April, 19</span>
                </div>              
              </div>
              <div class="media">
                <div class="media-left">
                  <a href="#">
                  </a>
                </div>
                <div class="media-body">
                   <h4 class="media-heading"><a href="#">Web Designer Express</a></h4>
                          <p>Your local best</p>                
                          <span>15 April, 19</span>
                </div>              
              </div>
              <div class="media">
                <div class="media-left">
                  <a href="#">
                  </a>
                </div>
                <div class="media-body">
                  <h4 class="media-heading"><a href="#">London web</a></h4>
                          <p>Best quality at a minimal price</p>                
                          <span>15 April, 19</span>
                </div>              
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  </section>
  <!-- / Properties  -->

  <!-- Footer -->

        </body>

</html>

<!-- Bootstrap core JavaScript
			================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/cbpAnimatedHeader.js"></script>
		<script src="js/jquery.appear.js"></script>
		<script src="js/SmoothScroll.min.js"></script>
		<script src="js/theme-scripts.js"></script>

