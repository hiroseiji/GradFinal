<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="favicon.icon">
		<title>Web and Vetted</title>
		 <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
        <!-- Bootstrap core CSS -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <!-- Material Design Bootstrap -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.7.3/css/mdb.min.css" rel="stylesheet">
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
      

        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">

	</head>
<form name='edit' action='editprofile.php' method='post'>
    <body>


<br/>
    <div class="container">
                <div class="col-md-12">
<h1>Freelancer Profile</h1>
                    <br/>
                    <h6>Your application has been confirmed, you can now edit your profile.</h6>

<section>
    <table>

<div><label>Full Name <span>*</span></label>
     <div class="col-md-6">
              <div class="form-group"><input name="Fullname" type="text" /></div>
    </div>
        </div>
         
<div><label>Email Address <span>*</span></label> <div class="col-md-6">
              <div class="form-group"><input name="Email" type="text"/></div>
    </div>
        </div>
    
    
    <div><label>Phone Number <span>*</span></label> <div class="col-md-6">
        <div class="form-group"><input name="Phonenumber" type="text" /></div> </div>
        </div>
        
    <div><label>Who can vouch for your work?<span>*</span></label> <div class="col-md-6">
              <div class="form-group"><input name="References" placeholder="add references" type="text" /></div> 
        </div>
        </div>
        
      Development Categories:<br/>
         <div class="col-md-6">
              <div class="form-group">
    <select name='Categories' input type="checkbox" style="width:155px;"><br/>
        <option value='Hospitality'>Hospitality</option>
        <option value='Transport'>Transport</option>
		<option value='Education'>Education</option>
        <option value='Technology'>Technology</option>
        <option value='SME'>Small Businesses</option>
        <option value='Corporate'>Corporate</option>
                  </select><br/> </div>
        </div>
    
<br/>
    <button type="submit" name='Update' value="Submit">Update</button>
         <button type="button" name="btnback" style="float:center;"><a href="Freelancer.php">Back</a></button>
          </table>
    </section>
   
        </div>
        </div>
    </body>
    
    </form>
        
        
 

      <br/>
    <br/>
    <br/>
     <br/>
    <br/>
     <br/>
		<footer>
			<div class="container text-center">
				<p>Web and Vetted © 2019 Copyright</p>
			</div>
		</footer>
    </html>
        
<?php
require_once("DataAccess.php");

try {
        
    $conn = (new DataAccess())->GetOracleConnection();
    
    if($_SERVER['REQUEST_METHOD'] == 'POST'){  //was form submitted
        
        //get user data into variables

			$names=$_REQUEST['Fullname']; 
			$email=$_REQUEST['Email'];
            $phonenumber=$_REQUEST['Phonenumber'];
            $references=$_REQUEST['References'];
			$categories=$_REQUEST['Categories'];
        
        //validate data
        if(empty($names) || empty($email) || empty($phonenumber) || empty($references)|| empty($categories) ){
            echo "<script>alert('Please enter missing data values !!');</script>";
        } else { 
        
            //get button clicked by user -- get operation//
           if (isset($_REQUEST['Update'])){ //UPDATE BUTTON
                
                
              
                     //execute using exec
                     $sql  = "UPDATE PROFILE SET NAMES='$names',EMAIL='$email',PHONENUMBER='$phonenumber',REFERENCES='$references',CATEGORIES='$categories' ";
                     $count= $conn->exec($sql);
                
               
                //METHOD 2 - USING CONCATENATION
                    //execute using exec
                    //$sql  = "INSERT INTO PROFILE(NAMES,EMAIL,PHONENUMBER,REFERENCES,CATEGORIES) 
                    //VALUES('$names','$email','$phonenumber','$references','$categories')"; 
					//$count= $conn->exec($sql);
                 
            }
                //END METHOD 2
                    
                    //check errors
                    if (PEAR::isError($count)) {
                        die ($count->getUserInfo()); //getDebugInfo()); //
                    }
                    //confirm
                    $msg = ($count>0) ? "Profile updated !!" : "Record update failed !!";
                    echo "<script>alert('$msg');</script>";
					
                    }
                    
            }
            
 }
    
catch (Exception $ex) {
    echo $msg;
    echo "<script>alert('$msg');</script>";
    exit();
}
    
?>

