
<html lang="en">
	<head>
        <center>
		<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	
	<body id="page-top">
		<!-- Navigation -->
		
				<!-- Collect the nav links, forms, and other content for toggling -->
        

            <br/>
              <a class="btn btn-warning black-text"  href="Logout.php" onclick="event.preventDefault();
              document.getElementById('logout.php').submit();"><i class=" fas fa-sign-out-alt"></i>Logout</a>
               <form id="logout.php" action="logout.php" method="POST">
                   
                  </form>
        <br/>
         <button type="button" name="btnback" style="float:center;"><a href="Admin.php">Back</a></button>
        <br/>
              <br/>
     
			

 <?php 
 require_once("DataAccess.php");
 try {
	 $conn =(new DataAccess())-> GetOracleConnection(); 
	 //get data from table
	 $sql="select Name, Email, Membership, PhoneNumber from Membership";
	 $result=$conn-> query($sql);
	 
	 //check errors
	 if(pear::isError($result)){
		 die($result->getMessage());
	 }
	 
	 //fetch all and free result
	 $arr = $result->fetchAll(MDB2_FETCHMODE_ASSOC);
	 $result->free();
	 $conn->disconnect();
	//var_dump($arr);
	 //display in html table
	 $row_count=count($arr); //get number of rows
	 if ($row_count> 0){
		 echo "<table border='3'> <text-align='left'>";
		 $keys = array_keys($arr[0]); //get keys for row 0
		 
		 //create column headers 
		 echo "<tr bgcolor='honeydew'>";
		 
		 foreach($keys as $keycol)
		 echo "<td>$keycol</td>";
	 }
	 echo"</tr>";
	 
	 //display data
	 foreach($arr as $row) {
		echo "<tr>" ;
		foreach($row as $key => $val){
			echo "<td>$val</td>";
		}
		echo"</tr>";
		
		//close for row_count = 0
		 
	 }
 } catch(Exception $ex){
	 echo $ex->getMessage();
 }
 ?>
        </body>
        </center>
    </head>
</html>

  
 
 
 