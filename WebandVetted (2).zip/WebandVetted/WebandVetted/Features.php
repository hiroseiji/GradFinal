<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="favicon.ico">
		<title>Web and Vetted</title>
		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->
		<link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
	</head>
	<body id="page-top">
		<!-- Navigation -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header page-scroll">
					
					 <h2>Web and Vetted</h2>
				
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li class="hidden">
							<a href="#page-top"></a>
						</li>
						<li>
							<a class="page-scroll" href="homepage.php">Home</a>
						</li>
						<li>
							<a class="page-scroll" href="About.php">About</a>
						</li>
						<li>
							<a class="page-scroll" href="#page-top">Features</a>
						</li>
						<li>
							<a class="page-scroll" href="Portfolio.php">Portfolio</a>
						</li>
						
						<li>
							<a class="page-scroll" href="Contact.php">Contact</a>
						</li>
                         <li>
							<a class="page-scroll" href="RE.php">Create Account</a>
						</li>
                        <li>
							<a class="page-scroll" href="Login.php">Sign in</a>
						</li>
					</ul>
				</div>
				<!-- /.navbar-collapse -->
			</div>
			<!-- /.container-fluid -->
		</nav>
         <br/>
        <br/>
        <br/>
<!--Features-->
		<section id="features" class="section-features">
			<div class="container">
				<div class="row">
					<div class="col-lg-12 text-center">
						<div class="section-title">
							<h2>Web and Vetted Features</h2>
						</div>
					</div>
				</div>
                <br/> 
                <h4>Our Web designers will provide the following services:</h4>
                <br/>
				<div class="row row-gutter">
					<div class="col-md-4 col-gutter">
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-television"></i></div>
							<div class="featured-text">
								<h4>Fully Responsive Design</h4>
								<p>INFRA theme looks awesome at any size, be it a Laptop screen, Mobile or Tablet.</p>
							</div>
						</div>
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-cogs"></i></div>
							<div class="featured-text">
								<h4>User Friendly Websites</h4>
								<p> Make use of our powerful yet easy-to-use theme options panel from setting to styling.</p>
							</div>
						</div>
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-newspaper-o"></i></div>
							<div class="featured-text">
								<h4>Custom Page Templates</h4>
								<p>Our themes come packaged with multiple pages templates including Authors Team, Full Width, and more to enhance your site.</p>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-gutter">
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-indent"></i></div>
							<div class="featured-text">
								<h4>Unlimited Widget Areas</h4>
								<p>We include just the right amount of useful widget areas and sidebars so you can place your content.</p>
							</div>
						</div>
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-paste"></i></div>
							<div class="featured-text">
								<h4>Custom Widgets</h4>
								<p>We include our own widgets for Reviews, Social, Advertising and additional custom widgets to enhance your site.</p>
							</div>
						</div>
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-dollar"></i></div>
							<div class="featured-text">
								<h4>AD Management</h4>
								<p>You can place various size of banner images in your sidebar and banners to other ad positions with ease.</p>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-gutter">
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-font"></i></div>
							<div class="featured-text">
								<h4>Icons and Fonts</h4>
								<p>We include FontAwesome Icons &amp; Hundreds of Google Fonts to Choose from to customize your site.</p>
							</div>
						</div>
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-wordpress"></i></div>
							<div class="featured-text">
								<h4>Compatible with Latest WordPress</h4>
								<p>We continuously test our themes so you will know they are always compatible with the latest version of WordPress.</p>
							</div>
						</div>
						<div class="featured-item">
							<div class="featured-icon"><i class="fa fa-file-code-o"></i></div>
							<div class="featured-text">
								<h4>Bootstrap Framework</h4>
								<p>The theme is based on Bootstrap framework. We use default row/col- Bootstrap grid system.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
        
       
         <br/>
        <br/>
        <br/>
         <br/>
        <br/>
		<footer>
			<div class="container text-center">
				<p>Web and Vetted © 2019 Copyright</p>
			</div>
		</footer>