<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="favicon.ico">
		<title>Web and Vetted</title>
		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->
		<link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
	</head>


   
      <h1>Admin
      </h1>

        <!-- Collapse -->
        

        <!-- Links -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent">

          <!-- Left -->
          <ul class="navbar-nav mr-auto">

          </ul>

        <!-- Right -->
    
              <a class="btn btn-warning black-text" style= "float: right;" href="Logout.php" onclick="event.preventDefault();
              document.getElementById('logout.php').submit();">Logout</a>
               <form id="logout.php" action="logout.php" method="POST">
                   
                  </form>
           

          </div>
   
      
         </header>

<br/>
     
 
    <!-- Navbar -->
        
         <!-- Sidebar -->
    <div class="sidebar-fixed position-fixed">

      <a class="logo-wrapper waves-effect">
    
      </a>

      <div class="list-group list-group-flush">
      <a href="applications.php" class="list-group-item list-group-item-action waves-effect black-text {{ request()->is('Freelancer') ? 'active' : '' }}">
        <i class="fas fa-chart-pie mr-3"></i>View Applications</a>
      <a href="Search.php" class="list-group-item list-group-item-action waves-effect black-text {{ request()->is('Freelancer/search') ? 'active' : '' }} {{ request()->is('Freelancer/provider/*') ? 'active' : '' }}">
        <i class="fab fa-searchengin mr-3"></i>Search</a>
      <a href="Blog.php" class="list-group-item list-group-item-action waves-effect black-text {{ request()->is('') ? 'active' : '' }}">
        <i class="fas fa-user-edit mr-3"></i>Client Feedback</a>
      <a href="mostrated.php" class="list-group-item list-group-item-action waves-effect black-text {{ request()->is('Freelancer') ? 'active' : '' }}">
        <i class="fas fa-chart-line mr-3"></i>Most Rated Activities</a>
      <a href="useractivity.php" class="list-group-item list-group-item-action waves-effect black-text {{ request()->is('Freelancer') ? 'active' : '' }}">
        <i class="fas fa-chart-line mr-3"></i>View User Activity</a>



      </div>

    </div>
    <!-- Sidebar -->
        
        
         <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
     <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
        <br/>
    <br/>
    <br/>
          <br/>
		<footer >
			<div class="container text-center">
				<p>Web and Vetted © 2019 Copyright</p>
			</div>
		</footer>