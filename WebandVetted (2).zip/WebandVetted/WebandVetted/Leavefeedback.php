<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="favicon.ico">
		<title>Web and Vetted</title>
		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->
		<link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
	</head>
	<body id="page-top">
		<!-- Navigation -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header page-scroll">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					
				</div>
                
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li class="hidden">
							<a href="#page-top"></a>
						</li>
						<li>
							<a class="page-scroll" href="homepage.php">Home</a>
						</li>
						<li>
							<a class="page-scroll" href="#page-top">About</a>
						</li>
						<li>
							<a class="page-scroll" href="#features">Features</a>
						</li>
						<li>
							<a class="page-scroll" href="#portfolio">Portfolio</a>
						</li>
						
						<li>
							<a class="page-scroll" href="Contact.php">Contact</a>
						</li>
                         <li>
							<a class="page-scroll" href="RE.php">Create Account</a>
						</li>
                        <li>
							<a class="page-scroll" href="Login.php">Sign in</a>
						</li>
					</ul>
				</div>
				<!-- /.navbar-collapse -->
			</div>
			<!-- /.container-fluid -->
		</nav>
        <br/>
                <br/>
        <br/>
                <br/>
<!--AboutUs-->
		 <div id="topwrap">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Leave Feedback</h1>
                    
                </div>
            </div><!-- row -->
        </div><!-- container -->
    </div>
    
    <main>
    
       <div class="col-md-6">
						<form name="LeaveFeedback" action='homepage.php' method='post'>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<input type="text" class="form-control" placeholder="Your Name *" name='Name' required>
									
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<input type="text" class="form-control" placeholder="Your Email *" name='Email' required>
										
									</div>
								</div>
							</div>
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<textarea class="form-control" placeholder="Your Message *" name='Feedback' required></textarea>
										
									</div>
								</div>
								<div class="clearfix"></div>
							</div>
						
						</form>
           <button type="submit" name="Submit" value='submit'>Submit</button>
           
					</div>

		
    </main>

        <br/>
            <br/>
             <br/>
            <br/>
                <button type="button" name="btnback" style="float:center;"><a href="Clients.php">Back</a></button>
            <br/>
            <br/>
            <br/>
    </body>
</html>

<?php
require_once("DataAccess.php");

try {
        
    $conn = (new DataAccess())->GetOracleConnection();
    
    if($_SERVER['REQUEST_METHOD'] == 'POST'){  //was form submitted
        
        //get user data into variables

			$name=$_REQUEST['Name']; 
			$email=$_REQUEST['Email'];
            $feedback=$_REQUEST['Feedback'];

        
        //validate data
        if(empty($name) || empty($email) || empty($feedback) ){
            echo "<script>alert('Please enter missing data values !!');</script>";
        } else { 
        
            //get button clicked by user -- get operation//
            if(isset($_REQUEST['Submit'])){ //SAVE BUTTON

                //METHOD 2 - USING CONCATENATION
                    //execute using exec
                    $sql  = "INSERT INTO FEEDBACK(NAME,EMAIL,FEEDBACK) VALUES('$name','$email','$feedback')"; 
					$count= $conn->exec($sql);
                 
            }
                //END METHOD 2
                    
                    //check errors
                    if (PEAR::isError($count)) {
                        die ($count->getUserInfo()); //getDebugInfo()); //
                    }
                    //confirm
                    $msg = ($count>0) ? "Feedback sent!!" : "Record saving failed !!";
                    echo "<script>alert('$msg');</script>";
					
                    }
                    
            }
            
 }
    
catch (Exception $ex) {
    echo $msg;
    echo "<script>alert('$msg');</script>";
    exit();
}
    
?>

