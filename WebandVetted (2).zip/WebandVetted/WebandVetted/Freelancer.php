<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="favicon.ico">
		<title>Web and Vetted</title>
		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->
		<link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
	</head>
	
<!--Features-->
		 <body>
        <!--Main Navigation-->
 
       <h1>Freelancer
        </h1>

        <!-- Collapse -->
      
        <!-- Links -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent">

          <!-- Left -->
          <ul class="navbar-nav mr-auto">

          </ul>

          <!-- Right -->
          <ul class="navbar-nav nav-flex-icons">
              
              <li class="nav-item ">
                  <a type="button" href='Membership.php' class="btn btn-success waves-effect">
              Membership</a> 
              </li> 

              <li class="nav-item">
              <a class="btn btn-warning black-text"  href="Logout.php" onclick="event.preventDefault();
              document.getElementById('logout.php').submit();"><i class=" fas fa-sign-out-alt"></i>Logout</a>
               <form id="logout.php" action="logout.php" method="POST">
                   
                  </form>
              </li>
          </ul>

        </div>

     
    
    <!-- Navbar -->

    <!-- Sidebar -->
    <div class="sidebar-fixed position-fixed">

      <a class="logo-wrapper waves-effect">
    
      </a>

      <div class="list-group list-group-flush">
      <a href="FreelancerDashboard.php" class="list-group-item list-group-item-action waves-effect black-text {{ request()->is('Freelancer/Profile') ? 'active' : '' }}">
        <i class="fas fa-chart-pie mr-3"></i>Application Progress</a>
      <a href="Search.php" class="list-group-item list-group-item-action waves-effect black-text {{ request()->is('Freelancer/search') ? 'active' : '' }} {{ request()->is('Freelancer/provider/*') ? 'active' : '' }}">
        <i class="fab fa-searchengin mr-3"></i>Search</a>
      <a href="EditProfile.php" class="list-group-item list-group-item-action waves-effect black-text {{ request()->is('') ? 'active' : '' }}"> Edit Profile</a>
          <a href="AddProfile.php" class="list-group-item list-group-item-action waves-effect black-text {{ request()->is('Freelancer/search') ? 'active' : '' }} {{ request()->is('Freelancer/provider/*') ? 'active' : '' }}">
        <i class="fas fa-user-edit mr-3"></i>Add Your Profile</a>
      <a href="trending.php" class="list-group-item list-group-item-action waves-effect black-text {{ request()->is('Freelancer/trending') ? 'active' : '' }}">
        <i class="fas fa-chart-line mr-3"></i>Check Trends</a>
      


         
      </div>

    </div>
    <!-- Sidebar -->

  </header>
  <!--Main Navigation-->



    <!-- Page content -->
    <main class="pt-5 mx-lg-5">

     
    </main>


     
	
    </body>
    <!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.2.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.7.3/js/mdb.min.js"></script>


<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
<script type="text/javascript">
    // Animations initialization
    new WOW().init();

    // Tooltips Initialization
      $(function () {
      $('[data-toggle="tooltip"]').tooltip()
      })
</script>


<script>
  @if(Session::has('userNotification'))


    Toastify({
      text: "{{ Session::get('userNotification') }}",
      duration: 4000,
      newWindow: true,
      gravity: "top", // `top` or `bottom`
      positionRight: true, // `true` or `false`
      backgroundColor: "#00C851",
    }).showToast();

  @endif

  @if(Session::has('applicationSent'))


    Toastify({
      text: "{{ Session::get('applicationSent') }}",
      duration: 4000,
      newWindow: true,
      gravity: "top", // `top` or `bottom`
      positionRight: true, // `true` or `false`
      backgroundColor: "#00C851",
    }).showToast();

  @endif

  @if(Session::has('found'))


Toastify({
  text: "{{ Session::get('found') }}",
  duration: 4000,
  newWindow: true,
  gravity: "top", // `top` or `bottom`
  positionRight: true, // `true` or `false`
  backgroundColor: "#00C851",
}).showToast();

@endif
  

  @if(Session::has('membershipExists'))


    Toastify({
      text: "{{ Session::get('membershipExists') }}",
      close: true,
      newWindow: true,
      gravity: "top", // `top` or `bottom`
      positionRight: true, // `true` or `false`
      backgroundColor: "#FF8800",
    }).showToast();

  @endif

  @if(Session::has('errors'))


Toastify({
  text: "{{ Session::get('errors') }}",
  close: true,
  newWindow: true,
  gravity: "top", // `top` or `bottom`
  positionRight: true, // `true` or `false`
  backgroundColor: "#CC0000",
}).showToast();

@endif



  @if(Session::has('accountCreated'))

    Toastify({
    text: "{{ Session::get('accountCreated') }}",
    duration: 4000,
    newWindow: true,
    gravity: "top", // `top` or `bottom`
    positionRight: true, // `true` or `false`
    backgroundColor: "#00C851",
    }).showToast();

@endif
</script>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
        <br/>
    <br/>
    <br/>
          <br/>
		<footer>
			<div class="container text-center">
				<p>Web and Vetted © 2019 Copyright</p>
			</div>
		</footer>