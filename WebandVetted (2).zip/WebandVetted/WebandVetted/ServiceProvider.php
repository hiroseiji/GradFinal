@extends('Freelancer.FreelancerMasterLayout')

@section('content')



<div class="container-fluid mt-5">
        <h2 class="text-center">{{$provider->companyName}}</h2>

        <div class="row">
            <div class="col"></div>
            <div class="col"></div>
            <div class="col">
  
            <button class="btn btn-success float-right" data-toggle="modal" data-target="#ratingModal"><i class="fas fa-comments mr-2"></i>Rate Service Provider</button>
            </div>
          </div>  

        <div class="d-flex justify-content-center wow fadeIn p-4">
            
                <div class="col-xl-5 col-md-4 mb-3 text-center">

                <img src="{{asset($provider->image)}}" class="img-fluid z-depth-1 rounded-circle" alt="Responsive image">
                    
                </div>
        </div>

        

        

        <div class="row wow fadeIn">

                <!--Grid column-->
                <div class="col-md-9 mb-4">
          
                  <!--Card-->
                  <div class="card">
          
                    <!--Card content-->
                    <div class="card-body">
          
                      <canvas id="myChart"></canvas>
          
                    </div>
          
                  </div>
                  <!--/.Card-->
          
                </div>
                <!--Grid column-->
          
                <!--Grid column-->
                <div class="col-md-3 mb-4">
          
                  <!--Card-->
                  <div class="card mb-4">
          
                    <!-- Card header -->
                    <div class="card-header text-center">
                      Pie chart
                    </div>
          
                    <!--Card content-->
                    <div class="card-body">
          
                      <canvas id="pieChart"></canvas>
          
                    </div>
          
                  </div>
                  <!--/.Card-->
          
                  <!--Card-->
                  <div class="card mb-4">
          
                    <!--Card content-->
                    <div class="card-body">
          
                      <!-- List group links -->
                      <div class="list-group list-group-flush">
                        <a class="list-group-item list-group-item-action waves-effect"><i class="fas fa-users mr-2"></i>Rating
                          <span class="badge badge-success badge-pill pull-right">4
                            <i class="fas fa-star-half-alt ml-1"></i>
                          </span>
                        </a>
                       
                      </div>
                      <!-- List group links -->
          
                    </div>
          
                  </div>
                  <!--/.Card-->
          
                </div>
                <!--Grid column-->
          
              </div>

              <div class="row card mb-5">
                  <h2 class="text-center">{{$provider->companyName}}'s Feedback</h2>

                  <table class="table  table-hover">
                      <thead>
                        <tr>
                          <th scope="col">Name</th>
                          <th scope="col">Feedback</th>
                          <th scope="col">Rating</th>
                        </tr>
                      </thead>
                      <tbody>
                        @foreach ($feedback as $userFeedback)
                            <tr>
                              <td>{{$userFeedback->name}}</td>
                              <td>{{$userFeedback->feedback}}</td>
                              <td>{{$userFeedback->rating}}</td>
                            </tr>
                        @endforeach
                        
                      </tbody>
                    </table>
              
              </div>

                  
              
</div>

@include('Modals.RatingModal')

<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.2/Chart.min.js"></script>
<!-- Charts -->
<script>
  // Line
  var ctx = document.getElementById("myChart").getContext('2d');
  var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ["Java", "NodeJs", "C#", "Go", "Flutter"],
      datasets: [{
        label: '# of Votes',
        data: [12, 19, 3, 2, 3],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)'
        ],
        borderColor: [
          'rgba(255,99,132,1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)'
        ],
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero: true
          }
        }]
      }
    }
  });

  //pie
  var ctxP = document.getElementById("pieChart").getContext('2d');
  var myPieChart = new Chart(ctxP, {
    type: 'pie',
    data: {
      labels: ["Php", "Java", "NodeJs", "C#", ".Net"],
      datasets: [{
        data: [300, 50, 100, 40, 120],
        backgroundColor: ["#F7464A", "#46BFBD", "#FDB45C", "#949FB1", "#4D5360"],
        hoverBackgroundColor: ["#FF5A5E", "#5AD3D1", "#FFC870", "#A8B3C5", "#616774"]
      }]
    },
    options: {
      responsive: true,
      legend: false
    }
  });


  //line
  var ctxL = document.getElementById("lineChart").getContext('2d');
  var myLineChart = new Chart(ctxL, {
    type: 'line',
    data: {
      labels: ["January", "February", "March", "April", "May", "June", "July"],
      datasets: [{
          label: "My First dataset",
          backgroundColor: [
            'rgba(105, 0, 132, .2)',
          ],
          borderColor: [
            'rgba(200, 99, 132, .7)',
          ],
          borderWidth: 2,
          data: [65, 59, 80, 81, 56, 55, 40]
        },
        {
          label: "My Second dataset",
          backgroundColor: [
            'rgba(0, 137, 132, .2)',
          ],
          borderColor: [
            'rgba(0, 10, 130, .7)',
          ],
          data: [28, 48, 40, 19, 86, 27, 90]
        }
      ]
    },
    options: {
      responsive: true
    }
  });


  //radar
  var ctxR = document.getElementById("radarChart").getContext('2d');
  var myRadarChart = new Chart(ctxR, {
    type: 'radar',
    data: {
      labels: ["Eating", "Drinking", "Sleeping", "Designing", "Coding", "Cycling", "Running"],
      datasets: [{
        label: "My First dataset",
        data: [65, 59, 90, 81, 56, 55, 40],
        backgroundColor: [
          'rgba(105, 0, 132, .2)',
        ],
        borderColor: [
          'rgba(200, 99, 132, .7)',
        ],
        borderWidth: 2
      }, {
        label: "My Second dataset",
        data: [28, 48, 40, 19, 96, 27, 100],
        backgroundColor: [
          'rgba(0, 250, 220, .2)',
        ],
        borderColor: [
          'rgba(0, 213, 132, .7)',
        ],
        borderWidth: 2
      }]
    },
    options: {
      responsive: true
    }
  });

  //doughnut
  var ctxD = document.getElementById("doughnutChart").getContext('2d');
  var myLineChart = new Chart(ctxD, {
    type: 'doughnut',
    data: {
      labels: ["Red", "Green", "Yellow", "Grey", "Dark Grey"],
      datasets: [{
        data: [300, 50, 100, 40, 120],
        backgroundColor: ["#F7464A", "#46BFBD", "#FDB45C", "#949FB1", "#4D5360"],
        hoverBackgroundColor: ["#FF5A5E", "#5AD3D1", "#FFC870", "#A8B3C5", "#616774"]
      }]
    },
    options: {
      responsive: true
    }
  });

</script>


@endsection