@extends('Clients.ClientsMasterLayout')

@section('content')
    <div class="container-fluid mt-5">
        <div class="card  wow fadeIn p-4">
            <h5>Application Progress : 25%</h5>
                    <div class="progress">
                        <div class="progress-bar bg-warning" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
            </div>
    </div>


    

@endsection