<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="favicon.ico">
		<title>Web and Vetted</title>
		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->
		<link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
	</head>
	<body id="page-top">
		<!-- Navigation -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<!--<div class="navbar-header page-scroll">-->
                    
							<h2>Web and Vetted</h2>
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li class="hidden">
							<a href="#page-top"></a>
						</li>
						<li>
							<a class="page-scroll" href="homepage.php">Home</a>
						</li>
						<li>
							<a class="page-scroll" href="About.php">About</a>
						</li>
						<li>
							<a class="page-scroll" href="Features.php">Features</a>
						</li>
						<li>
							<a class="page-scroll" href="Portfolio.php">Portfolio</a>
						</li>
						
						<li>
							<a class="page-scroll" href="Contact.php">Contact</a>
                        
						</li>
                        
                         <li>
							<a class="page-scroll" href="RE.php">Create Account</a>
						</li>
                        
                        
					</ul>
				</div>
				<!-- /.navbar-collapse -->
			
			<!-- /.container-fluid -->
		</nav>
        
        <br>
            <br>
            <br>
           
        
        <form name='Login' action='Login.php' method='post'>
                  <br> <br>
            <br>
            <br> <center>
             <!--<section id="contact" class="dark-bg">
			
				<div class="row">
                    <div class="col-lg-12 text-center">-->
                    <div class="section-title">
							<h2>Login</h2>
        
        <br>
            <br>
            <br>
           
         Email:<br/>
                         
              <div class="form-group">
    <input type='text' name='Email'/><br/>
                             </div>
                       
        
         Password:<br/>
                  
              <div class="form-group">
    <input type='password' name='Password'/><br/>
                       </div>
                      
        
        Account Type:<br/> 
                
              <div class="form-group">
        <select name='usertype' style="width:170px"><br/>
        <option value='0'>Select...</option>
        <option value='Admin'>Admin</option>                          
        <option value='Client'>Client</option>
        <option value='Freelancer'>Freelancer</option>
        </select><br/>
                             </div>
                        
                
            
    <br/>      
    <input type='submit' name='btnlogin' style= "float: center;"  value='Login'/>
    <input type='submit' name='btcancel' style= "float: center;" value='Reset'/>
            </div>
	</center>
        </form>
</body>

        
        <?php

require_once("DataAccess.php");

try {
        
    $conn = (new DataAccess())->GetOracleConnection();

    if($_SERVER['REQUEST_METHOD'] == 'POST'){  //was form submitted
        
        //get user data into variables
        $email=$_REQUEST['Email']; 
        $password=$_REQUEST['Password'];
        $usertype=$_REQUEST['usertype'];

        //validate data
        if(empty($email) || empty($password)){
            
        } else { 
        
            //get button clicked by user -- get operation//
            if(isset($_REQUEST['btnlogin'])){ //LOGIN BUTTON
                    
                    //determine TABLENAME AND PAGENAME based on selected USERTYPE
                    $tablename = "";
                    $pagename  = "";
                    if    ($usertype == 'Admin'){ $tablename = 'Registration';       $pagename='admin.php';}
                    elseif($usertype == 'Client'){ $tablename  = 'Registration';  $pagename='Clients.php';}
                    elseif($usertype == 'Freelancer'){ $tablename  = 'Registration';  $pagename='Freelancer.php';}
                
                    $sqlAdmin  = "SELECT * FROM Registration WHERE EMAIL=? AND PASSWORD=?"; 
                    $sqlUsers  = "SELECT * FROM Registration WHERE EMAIL=? AND PASSWORD=?"; 
                    $usertype  = Array(  'Admin' , 'Client', 'Freelancer'  );
                    $values = Array($email,$password);

                    //execute Users
                    $stmt = $conn->prepare($sqlUsers, null, MDB2_PREPARE_RESULT); //null AUTO_DETERMINE types
                    $resultUsers = $stmt->execute($values);
                    //check errors
                    if (PEAR::isError($resultUsers)) {
                        die ($resultUsers->getUserInfo()); //getDebugInfo()); //
                    }
                    $arrUsers    = $resultUsers->fetchAll(MDB2_FETCHMODE_ASSOC);
                    $countUsers  = count($arrUsers); //fetch returns Array so use count to get count
                    
                    //found?? or not??
                    if($countUsers>0){ //user successfully logged, redirect to user page determined above
                        //redirect to company
                        echo "<script> location.href='$pagename'; </script>";
                        exit(); //prevents code down from further execution after redirection
                    }else{ //user details not found, give error message
                        $msg = "Invalid email or password !!";
                        echo "<script>alert('$msg');</script>";
                    }

            } elseif (isset($_REQUEST['btncancel'])){ //CANCEL BUTTON  
                    //no need to code reset / cancel button, it simply clears all fields on submission 
            }
            
        }
    
    }
    

} catch (Exception $ex) {
    $msg=$ex->getMessage();
    echo $msg;
    echo "<script>alert('$msg');</script>";
    exit();
}

?>
<!-- Bootstrap core JavaScript
			================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/cbpAnimatedHeader.js"></script>
		<script src="js/jquery.appear.js"></script>
		<script src="js/SmoothScroll.min.js"></script>
		<script src="js/theme-scripts.js"></script>
