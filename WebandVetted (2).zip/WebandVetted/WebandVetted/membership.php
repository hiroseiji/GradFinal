<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{csrf_token()}}">
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Web and Vetted</title>
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
        <!-- Bootstrap core CSS -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.2.1/css/bootstrap.min.css" rel="stylesheet">
        <!-- Material Design Bootstrap -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.7.3/css/mdb.min.css" rel="stylesheet">
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        
        <link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

        <link rel="shortcut icon" type="image/x-icon" href="{{ asset('images/1552217122.ico')}}">

        <link href="{{ asset('css/welcome.css') }}" rel="stylesheet">

        <link href="{{ asset('css/sideNav.css') }}" rel="stylesheet">

        <link href="{{asset('css/freelancer.css')}}" rel="stylesheet" >

      

    </head>
   <form action='membership.php' method='post'>
   
      
      <div class="modal-body">
<!-- Default form register -->
     
      
    <p class="h4 mb-4">Apply For Membership</p>
<div class="container">
                <div class="col-md-12">
    <div class="form-row mb-4">
        
        <div class="col-6">
            <!-- First name -->
            Fullname:<br/>
        <input type="text" name='name' required />
        </div>
        
         
        <div class="col-6">
            <!-- Last name -->
             Email:<br/>
            <input type="text" name='email'  required />
        </div>
    </div>
         
    <div class="form-row mb-4">
            
  <div class="col-14">
      <!-- Last name -->
      <select  name='membership' style="width:155px;" required >
          <option disabled>Select Membership Package</option>
          <option value="Premium">Premium P599/pm</option>
          <option value="Median">Median P350/pm</option>
        </select>      
    </div>
       
    </div>

    <!-- Phone number -->
           Phone Number:<br/>
    <input type="text" name='phonenumber'  required />


    <!-- Submit button -->
    <button class="btn btn-info my-4 btn-block" name='Submit' >Apply</button>
           <input type='reset' name='btcancel' style= "float: right;" value='Reset'/>
       </div>
          </div>
       </div>
       
</form>
<!-- Default form register -->

    
    
       <button type="button" name="btnback" style="float:right;"><a href="Freelancer.php">Back</a></button>
    

<!-- Central Modal Small -->


    <br/>
    <br/>
    <br/>
    <br/>
     <br/>
    <br/>
    <br/>
    <br/>
    <footer>
			<div class="container text-center">
				<p>Web and Vetted © 2019 Copyright</p>
			</div>
		</footer>
    <?php
require_once("DataAccess.php");

try {
        
    $conn = (new DataAccess())->GetOracleConnection();
    
    if($_SERVER['REQUEST_METHOD'] == 'POST'){  //was form submitted
        
        //get user data into variables

			$name=$_REQUEST['name']; 
			$email=$_REQUEST['email'];
            $membership=$_REQUEST['membership'];
            $phonenumber=$_REQUEST['phonenumber'];
            
        //validate data
        if(empty($name) || empty($email) || empty($membership)|| empty($phonenumber)){
            echo "<script>alert('Please enter missing data values !!');</script>";
        } else { 
        
            //get button clicked by user -- get operation//
            if(isset($_REQUEST['Submit'])){ //SAVE BUTTON
                
               
                //METHOD 2 - USING CONCATENATION
                    //execute using exec
                    $sql  = "INSERT INTO MEMBERSHIP(NAME,EMAIL,MEMBERSHIP,PHONENUMBER) 
                    VALUES('$name','$email','$membership','$phonenumber')"; 
					$count= $conn->exec($sql);
                 
            }
                //END METHOD 2
                    
                    //check errors
                    if (PEAR::isError($count)) {
                        die ($count->getUserInfo()); //getDebugInfo()); //
                    }
                    //confirm
                    $msg = ($count>0) ? "Record saved successfully !!" : "Record saving failed !!";
                    echo "<script>alert('$msg');</script>";
					
                    }
                    
            }
            
 }
    
catch (Exception $ex) {
    echo $msg;
    echo "<script>alert('$msg');</script>";
    exit();
}
    
?>

