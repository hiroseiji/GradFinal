<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="favicon.ico">
		<title>Web and Vetted</title>
		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->
		<link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
	</head>
	<body id="page-top">
		<!-- Navigation -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header page-scroll">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					
				</div>
                
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li class="hidden">
							<a href="#page-top"></a>
						</li>
						<li>
							<a class="page-scroll" href="homepage.php">Home</a>
						</li>
						<li>
							<a class="page-scroll" href="#page-top">About</a>
						</li>
						<li>
							<a class="page-scroll" href="#features">Features</a>
						</li>
						<li>
							<a class="page-scroll" href="#portfolio">Portfolio</a>
						</li>
						
						<li>
							<a class="page-scroll" href="Contact.php">Contact</a>
						</li>
                         <li>
							<a class="page-scroll" href="RE.php">Create Account</a>
						</li>
                        <li>
							<a class="page-scroll" href="Login.php">Sign in</a>
						</li>
					</ul>
				</div>
				<!-- /.navbar-collapse -->
			</div>
			<!-- /.container-fluid -->
		</nav>
        <br/>
                <br/>
        <br/>
                <br/>
<!--AboutUs-->
		 <div id="topwrap">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Customer Reviews</h1>
                    <p class="sub-title">Check our latest reviews and see what features helped other clients choose Web and Vetted as their technology partner.</p>
                </div>
            </div><!-- row -->
        </div><!-- container -->
    </div>
    
    <main>
    
        <div class="container">
            <div class="row custom-reviews">
                <div class="col-md-12 ">
                    <div class="resume">
                        <p class="stars">
                            <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                            <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                            <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                            <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                            <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                            <span class="text text-center">4.8 Overall Satisfaction Rating</span>
                            <small>Based on <strong>259 Ratings</strong> from Actual Customers</small>
                        </p>
                    </div>

                    <!-- Exibir detalhes de cada review -->
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Phuong</p>,
                            <p class="rev-date">13 May 2019</p>
                            <p class="rev-loc">Francistown</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"I have been very satisfied with the overall experience with eDirectory.  
Daniel Storm have been amazing since the beginnining!"</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Masego</p>,
                            <p class="rev-date">09 May 2019</p>
                            <p class="rev-loc">Ghanzi</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Liked the interaction and flexibility.  Appreciated Daniels support as we looked at what to buy and how to implement."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Jennifer</p>,
                            <p class="rev-date">08 May 2019</p>
                            <p class="rev-loc">Mahalapye</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Fast. Intuitive. Excellent!"</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Mason</p>,
                            <p class="rev-date">07 May 2019</p>
                            <p class="rev-loc"></p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"The shopping experience was really good. Got a call from eDirectory representative promptly after the purchase. He explained the setup process. Very pleased with the experience."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">RH</p>,
                            <p class="rev-date">01 May 2019</p>
                            <p class="rev-loc"></p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Quick responses, straightforward and clear. Thanks for your help!"</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Eric</p>,
                            <p class="rev-date">29 Apr 2019</p>
                            <p class="rev-loc">Serowe</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"I dealt with Daniel Storm and he was very helpful and well informed."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">F. Lucas</p>,
                            <p class="rev-date">19 Apr 2019</p>
                            <p class="rev-loc">Kasane/p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Daniel was extremely helpful in answering my baseline questions so that I could make a more informed decision about this service."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Bola I</p>,
                            <p class="rev-date">30 Mar 2019</p>
                            <p class="rev-loc"></p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(4.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"So far I am happy with the platform. It seems to behave as advertised. Still getting my head round the platform and so far it works well."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Lee</p>,
                            <p class="rev-date">27 Mar 2019</p>
                            <p class="rev-loc">Palapye</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(4.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"So far, great! Looking forward to launching and learning. 
Daniel was a lot of help and very cool to deal with!
Thanks
Lee"</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Q Media</p>,
                            <p class="rev-date">24 Mar 2019</p>
                            <p class="rev-loc">Palapye</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Site was easy to use. It seems like the product we've always been looking for. It's going to be a lot of work but I believe we made a great first step today."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Marshall C</p>,
                            <p class="rev-date">15 Mar 2019</p>
                            <p class="rev-loc">Jwaneng</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Daniel has been instrumental in my decision to go with eDirectory.com"</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Seb</p>,
                            <p class="rev-date">08 Mar 2019</p>
                            <p class="rev-loc"></p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Great comms, guidance and assistance."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Linda B</p>,
                            <p class="rev-date">21 Feb 2019</p>
                            <p class="rev-loc"></p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"My experience has been awesome.  Daniel is really engaged, knowledgeable and extremely helpful with the onboard process."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Kirk</p>,
                            <p class="rev-date">13 Feb 2019</p>
                            <p class="rev-loc">IA, Gaborone</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Great experience. Daniel helped me get setup and was able to answer my questions."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Tony D</p>,
                            <p class="rev-date">12 Feb 2019</p>
                            <p class="rev-loc">Francistown</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"The phone quality with Daniel Storm was quite poor but very clear with the support group. Very strange in that I believe Daniel is located in Virginia(?) whereas the support group is located somewhere in South America."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">NM</p>,
                            <p class="rev-date">06 Feb 2019</p>
                            <p class="rev-loc">Gaborone</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Daniel worked with me and was patient in answering all of my questions. I look forward to seeing the end result of my new site."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Caroline</p>,
                            <p class="rev-date">06 Feb 2019</p>
                            <p class="rev-loc">Orapa</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"My experience with edirectory staff was professional and to the point. Very informative and helpful."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">J. Millender</p>,
                            <p class="rev-date">05 Feb 2019</p>
                            <p class="rev-loc">Orapa</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Great experience so far. Daniel was very helpful and answered all my questions. He followed up often and I really like all the educational material I recieved throughout the checklist."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Cory C</p>,
                            <p class="rev-date">04 Feb 2019</p>
                            <p class="rev-loc">Gaborone</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"I have been working on creating an online directory for my city for over a year, and I can't say how thankful I am to come across eDirectory, just wish it happened sooner."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Joerg W</p>,
                            <p class="rev-date">17 Jan 2019</p>
                            <p class="rev-loc"></p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(4.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"I just started with eDirectory and I am very satisfied with information and support."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Usman C</p>,
                            <p class="rev-date">26 Nov 2018</p>
                            <p class="rev-loc">Gaborone</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Its just been a great experience over all I am just happy to purchase this and I am looking forward to seeing the results."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Nezam</p>,
                            <p class="rev-date">26 Nov 2018</p>
                            <p class="rev-loc">Gaborone</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Great service. Thank you"</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Ben V</p>,
                            <p class="rev-date">26 Nov 2018</p>
                            <p class="rev-loc"></p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Very persistent and eDirectory have improved since the few years."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">JS</p>,
                            <p class="rev-date">23 Nov 2018</p>
                            <p class="rev-loc">Gaborone</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"Daniel was helpful in answering my questions.  No problem signing up."</p>
                        </div>
                                            <div class="col-md-12 box-custom">
                            <p class="rev-name">Alex</p>,
                            <p class="rev-date">22 Nov 2018</p>
                            <p class="rev-loc">Mahalapye</p>
                            <div class="rev-over">
                                <p class="stars">
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <span class="glyphicon glyphicon-star icon-flipped" aria-hidden="true"></span>
                                                                        <small>(5.0)</small>
                                </p>
                            </div>
                            <p class="rev-com">"eDirectory was super helpful in clarifying certain features and pricing options, and were even flexible with billing!"</p>
                        
            </div>
        </div>
            </div>
        </div>
        
    </main>

        <br/>
            <br/>
             <br/>
            <br/>
                <button type="button" name="btnback" style="float:right;"><a href="admin.php">Back</a></button>
            <br/>
            <br/>
            <br/>
        
		<footer>
			<div class="container text-center">
				<p>Web and Vetted © 2019 Copyright</p>
			</div>
		</footer>