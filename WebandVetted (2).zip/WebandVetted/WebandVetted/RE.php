<center>
<head>
     
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="favicon.ico">
		<title>Web and Vetted</title>
		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->
		<link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
	</head>
<body>
    
    <nav class="navbar navbar-default navbar-fixed-top">
			<div class="container">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header page-scroll">
                    <h2>Web and Vetted</h2>
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li class="">
							<a href="#page-top"></a>
						</li>
						<li>
							<a class="page-scroll" href="homepage.php">Home</a>
						</li>
						
					</ul>
				</div>
				<!-- /.navbar-collapse -->
			</div>
			<!-- /.container-fluid -->
		</nav>
      
	<form name='RE' action='RE.php' method='post'>
<br> 
        <!--<section id="contact" class="dark-bg">
			<div class="container">
				<div class="row">--> <br>
            <br>
            <br>
                    <div class="section-title">
							<h2>Registration</h2>
        <br>
            <br>
            <br>
    Name:<br/>
                        <div class="form-group">
    <input type='text' font color="black" name='Name'/><br/>
                        </div>
    Email:<br/>
                            <div class="form-group">
    <input type='text' name='Email'/><br/>
                            </div>
    Phone Number:<br/>
                                <div class="form-group">
    <input type='text' name='Phonenumber'/><br/>
                                </div>
    Password:<br/>
                                    <div class="form-group">
    <input type='password' name='Password'/><br/>
                                    </div>
    
    Account Type:<br/>
                                        <div class="form-group">
    <select name='AccountType' style="width:155px;"><br/>
        <option value='0'>Select...</option>
        <option value='Male'>Freelancer</option>
        <option value='Female'>Admin</option>
		<option value='Female'>Client</option>
                                            </select><br/> </div>
        <br/>
        <br/>
    
     <input type='submit' name='btnsave' style= "float: center;"  value='Save'/>
    <input type='reset' name='btcancel' style= "float: center;" value='Reset'/>
	<!--<td><button type="reset" name="btncancel" style="float:right;" >Home</button></td>-->
        <br/>
        <br/>
        <br/>
        Already have an account? Sign in  
        <button type="button" name="btnlogin" style="float:center;"><a href="Login.php">Login</a></button>
     
                </div>
    </form>
    </body>
</center>
           

<?php
require_once("DataAccess.php");

try {
        
    $conn = (new DataAccess())->GetOracleConnection();
    
    if($_SERVER['REQUEST_METHOD'] == 'POST'){  //was form submitted
        
        //get user data into variables

			$name=$_REQUEST['Name']; 
			$email=$_REQUEST['Email'];
            $phone_number=$_REQUEST['Phonenumber'];
			$password=$_REQUEST['Password'];
			$accounttype=$_REQUEST['AccountType'];
        
        //validate data
        if(empty($name) || empty($email) || empty($phone_number) || empty($password) || empty($accounttype)){
            echo "<script>alert('Please enter missing data values !!');</script>";
        } else { 
        
            //get button clicked by user -- get operation//
            if(isset($_REQUEST['btnsave'])){ //SAVE BUTTON

                //METHOD 2 - USING CONCATENATION
                    //execute using exec
                    $sql  = "INSERT INTO REGISTRATION(NAME,EMAIL,PHONENUMBER,PASSWORD,ACCOUNTTYPE) VALUES('$name','$email','$phone_number','$password','$accounttype')"; 
					$count= $conn->exec($sql);
                 
            }
                //END METHOD 2
                    
                    //check errors
                    if (PEAR::isError($count)) {
                        die ($count->getUserInfo()); //getDebugInfo()); //
                    }
                    //confirm
                    $msg = ($count>0) ? "Record saved successfully !!" : "Record saving failed !!";
                    echo "<script>alert('$msg');</script>";
					
                    }
                    
            }
            
 }
    
catch (Exception $ex) {
    echo $msg;
    echo "<script>alert('$msg');</script>";
    exit();
}
    
?>
<!-- Bootstrap core JavaScript
			================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
		<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/cbpAnimatedHeader.js"></script>
		<script src="js/jquery.appear.js"></script>
		<script src="js/SmoothScroll.min.js"></script>
		<script src="js/theme-scripts.js"></script>

