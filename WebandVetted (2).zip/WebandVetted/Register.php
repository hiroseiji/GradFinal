<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="icon" href="favicon.ico">
		<title>Web and Vetted</title>
		<!-- Bootstrap core CSS -->
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
		<!-- Custom styles for this template -->
		<link href="css/owl.carousel.css" rel="stylesheet">
		<link href="css/owl.theme.default.min.css"  rel="stylesheet">
		<link href="css/animate.css" rel="stylesheet">
		<link href="css/style.css" rel="stylesheet">
        
        
	</head>

    
    <form action="Registration.php" method="post">

        <fieldset>
            <table>

				<td><h2>Create Account</h2></td>
				<tr>
                    <td><label><b>Your name</b></label>
                    <td><input type="text" placeholder="First name" name="Firstname" required></td>
                </tr>
                <tr>
                    <td><label><b>Your email</b></label>
                    <td><input type="text" placeholder="Last name" name="Lastname" required></td>
				<tr>
                    <td><label><b>Your Cellphone</b></label>
                    <td><input type="text" placeholder="" name="Password" required></td>
                </tr>
                <tr>
				<td><label><b>Your password</b></label>
                    <td><input type="text" placeholder="" name="Email" required></td>
                </tr>
            <tr>
				<td><label><b>Phone No</b></label>
                    <td><input type="text" placeholder="" name="" required></td>
                </tr>
		
        
       
    
            <!-- <div class="md-form mb-4">
              <i class="fas fa-lock prefix grey-text"></i>
              <input type="password" id="orangeForm-pass" name="password" class="form-control validate"
                autocomplete="off" required>
              <label data-error="wrong" data-success="right" for="orangeForm-pass">Your password</label>
            </div>
            <div class="md-form mb-5">
                    What account would you like to create ?
                    <select class="browser-default custom-select custom-select-sm" name="accountType">
                        <option selected>Open this select menu</option>
                        <option value="Client">Ordinary User</option>
                        <option value="Freelancer">Freelancer</option>
                    </select>                    
                </div>
               </div> -->
            <div class="row">
								<div class="col-lg-12 text-center">
									<div id="success"></div>
									<button type="submit" name="btnsave" style="float:left;" class="btn">Sign Up</button>
								</div>
            </div>
</form>
            
<?php
require_once("DataAccess.php");

try {
        
    $conn = (new DataAccess())->GetOracleConnection();
    
    if($_SERVER['REQUEST_METHOD'] == 'POST'){  //was form submitted
        
        //get user data into variables

			$name=$_REQUEST['Name']; 
			$email=$_REQUEST['Email'];
            $pnumber=$_REQUEST['PhoneNumber'];
            $password=$_REQUEST['Password'];
           
        //validate data
        if(empty($name) || empty($email) || empty($pnumber) || empty($password) || ){
            echo "<script>alert('Please enter missing data values !!');</script>";
        } else { 
        
            //get button clicked by user -- get operation//
            if(isset($_REQUEST['btnsave'])){ //SAVE BUTTON

                
                    $sql  = "INSERT INTO REGISTRATION (NAME,EMAIL,PHONENUMBER,PASSWORD) VALUES  ('$name','$email','$pnumber','$password')"; 
					$count= $conn->exec($sql);
                 
            }
                //END METHOD 2
                    
                    //check errors
                    if (PEAR::isError($count)) {
                        die ($count->getUserInfo()); //getDebugInfo()); //
                    }
                    //confirm
                    $msg = ($count>0) ? "Record saved successfully !!" : "Record saving failed !!";
                    echo "<script>alert('$msg');</script>";

          
                    }
                    //confirm
                    //$msg = ($count>0) ? "Record deleted successfully !!" : "Record deleting failed !!";
                    //echo "<script>alert('$msg');</script>";
            }
            
        }
    
catch (Exception $ex) {
    echo $msg;
    echo "<script>alert('$msg');</script>";
    exit();
}
    
?>

                